package com.tomslists;

public interface IteratorForGenericList {
}
