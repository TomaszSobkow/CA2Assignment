package com.comparators;


public interface PersonComparable<T>{

    int compareTo(T element);
}
