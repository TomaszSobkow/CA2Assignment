package com.calculator;

public class InfixCalculator {

    public static double evaluate(String expression){
        return 0;
    }
    public static void evaluate(){

    }

}
