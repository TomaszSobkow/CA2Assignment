package com.exceptions;

public class MyEmptyStackException extends Exception{

    public MyEmptyStackException(String message){
        super(message);
    }
}
